import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { MessageTable } from "@/components/messages/message-table"
import { SendMessageDialog } from "@/components/messages/send-message-dialog"
import { MessageStats } from "@/components/messages/message-stats"
import { MessageTemplates } from "@/components/messages/message-templates"
import { Button } from "@/components/ui/button"
import { MessageSquare } from "lucide-react"

export default function MessagesPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Messages</h2>
              <p className="text-muted-foreground">Send and manage SMS messages</p>
            </div>
            <SendMessageDialog>
              <Button>
                <MessageSquare className="mr-2 h-4 w-4" />
                Send Message
              </Button>
            </SendMessageDialog>
          </div>

          <MessageStats />

          <div className="grid gap-4 md:grid-cols-3">
            <div className="md:col-span-2">
              <MessageTable />
            </div>
            <div>
              <MessageTemplates />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
