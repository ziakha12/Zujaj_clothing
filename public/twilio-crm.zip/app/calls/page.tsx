import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { CallTable } from "@/components/calls/call-table"
import { MakeCallDialog } from "@/components/calls/make-call-dialog"
import { CallStats } from "@/components/calls/call-stats"
import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"

export default function CallsPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Calls</h2>
              <p className="text-muted-foreground">Manage your calls and view call history</p>
            </div>
            <MakeCallDialog>
              <Button>
                <Phone className="mr-2 h-4 w-4" />
                Make Call
              </Button>
            </MakeCallDialog>
          </div>

          <CallStats />
          <CallTable />
        </main>
      </div>
    </div>
  )
}
