import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { InvoiceTable } from "@/components/invoices/invoice-table"
import { CreateInvoiceDialog } from "@/components/invoices/create-invoice-dialog"
import { InvoiceStats } from "@/components/invoices/invoice-stats"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function InvoicesPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Invoices</h2>
              <p className="text-muted-foreground">Create and manage your invoices</p>
            </div>
            <CreateInvoiceDialog>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Invoice
              </Button>
            </CreateInvoiceDialog>
          </div>

          <InvoiceStats />
          <InvoiceTable />
        </main>
      </div>
    </div>
  )
}
