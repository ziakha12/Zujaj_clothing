import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { UserTable } from "@/components/users/user-table"
import { CreateUserDialog } from "@/components/users/create-user-dialog"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function UsersPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Users</h2>
              <p className="text-muted-foreground">Manage your team members and their permissions</p>
            </div>
            <CreateUserDialog>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add User
              </Button>
            </CreateUserDialog>
          </div>

          <UserTable />
        </main>
      </div>
    </div>
  )
}
