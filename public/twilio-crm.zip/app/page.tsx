import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { Phone, MessageSquare, FileText, Users, DollarSign } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Calls</CardTitle>
                <Phone className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,234</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Messages Sent</CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5,678</div>
                <p className="text-xs text-muted-foreground">+8% from last month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">89</div>
                <p className="text-xs text-muted-foreground">+3 new this week</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$12,345</div>
                <p className="text-xs text-muted-foreground">+15% from last month</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Recent Call Activity</CardTitle>
                <CardDescription>Latest calls and their status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent">
                    <Phone className="h-4 w-4" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">Call to +1 (555) 123-4567</p>
                    <p className="text-sm text-muted-foreground">Duration: 5:23 • Completed</p>
                  </div>
                  <div className="text-sm text-muted-foreground">2 min ago</div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent">
                    <Phone className="h-4 w-4" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">Call to +1 (555) 987-6543</p>
                    <p className="text-sm text-muted-foreground">Duration: 12:45 • Completed</p>
                  </div>
                  <div className="text-sm text-muted-foreground">15 min ago</div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-destructive/10">
                    <Phone className="h-4 w-4 text-destructive" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">Call to +1 (555) 456-7890</p>
                    <p className="text-sm text-muted-foreground">Failed • No answer</p>
                  </div>
                  <div className="text-sm text-muted-foreground">1 hour ago</div>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks and shortcuts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-2">
                  <button className="flex items-center justify-start space-x-2 rounded-lg border p-3 text-left hover:bg-accent hover:text-accent-foreground transition-colors">
                    <Phone className="h-4 w-4" />
                    <span className="text-sm font-medium">Make New Call</span>
                  </button>

                  <button className="flex items-center justify-start space-x-2 rounded-lg border p-3 text-left hover:bg-accent hover:text-accent-foreground transition-colors">
                    <MessageSquare className="h-4 w-4" />
                    <span className="text-sm font-medium">Send Message</span>
                  </button>

                  <button className="flex items-center justify-start space-x-2 rounded-lg border p-3 text-left hover:bg-accent hover:text-accent-foreground transition-colors">
                    <FileText className="h-4 w-4" />
                    <span className="text-sm font-medium">Create Invoice</span>
                  </button>

                  <button className="flex items-center justify-start space-x-2 rounded-lg border p-3 text-left hover:bg-accent hover:text-accent-foreground transition-colors">
                    <Users className="h-4 w-4" />
                    <span className="text-sm font-medium">Add User</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
