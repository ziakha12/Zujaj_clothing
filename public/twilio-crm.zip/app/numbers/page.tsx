import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { NumberTable } from "@/components/numbers/number-table"
import { PurchaseNumberDialog } from "@/components/numbers/purchase-number-dialog"
import { NumberStats } from "@/components/numbers/number-stats"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function NumbersPage() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 border-r bg-sidebar md:block">
        <DashboardSidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <DashboardHeader />

        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Phone Numbers</h2>
              <p className="text-muted-foreground">Manage your Twilio phone numbers and assignments</p>
            </div>
            <PurchaseNumberDialog>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Purchase Number
              </Button>
            </PurchaseNumberDialog>
          </div>

          <NumberStats />
          <NumberTable />
        </main>
      </div>
    </div>
  )
}
