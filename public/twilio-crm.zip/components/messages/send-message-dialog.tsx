"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Send, MessageSquare } from "lucide-react"

interface SendMessageDialogProps {
  children: React.ReactNode
}

export function SendMessageDialog({ children }: SendMessageDialogProps) {
  const [open, setOpen] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [formData, setFormData] = useState({
    phoneNumber: "",
    fromNumber: "",
    message: "",
    template: "",
  })

  const messageTemplates = [
    { id: "welcome", name: "Welcome Message", content: "Welcome to our service! We're excited to have you on board." },
    {
      id: "appointment",
      name: "Appointment Reminder",
      content: "This is a reminder about your appointment tomorrow at [TIME]. Please reply to confirm.",
    },
    {
      id: "followup",
      name: "Follow-up",
      content: "Thank you for your inquiry. Our team will get back to you within 24 hours.",
    },
    {
      id: "support",
      name: "Support Response",
      content: "We've received your support request and are working on it. We'll update you soon.",
    },
  ]

  const handleTemplateSelect = (templateId: string) => {
    const template = messageTemplates.find((t) => t.id === templateId)
    if (template) {
      setFormData({ ...formData, message: template.content, template: templateId })
    }
  }

  const getMessageLength = () => formData.message.length
  const getSegmentCount = () => Math.ceil(formData.message.length / 160)
  const getEstimatedCost = () => (getSegmentCount() * 0.0075).toFixed(4)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSending(true)

    // Simulate message sending
    setTimeout(() => {
      console.log("Sending message:", formData)
      setIsSending(false)
      setOpen(false)
      setFormData({
        phoneNumber: "",
        fromNumber: "",
        message: "",
        template: "",
      })
    }, 2000)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Send New Message</DialogTitle>
          <DialogDescription>Send an SMS message to a phone number.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="to-number" className="text-right">
                To Number
              </Label>
              <Input
                id="to-number"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="from-number" className="text-right">
                From Number
              </Label>
              <Select
                value={formData.fromNumber}
                onValueChange={(value) => setFormData({ ...formData, fromNumber: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select sender number" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="+15551234567">+1 (555) 123-4567 - Main Line</SelectItem>
                  <SelectItem value="+15559876543">+1 (555) 987-6543 - Sales Line</SelectItem>
                  <SelectItem value="+15555555555">+1 (555) 555-5555 - Support Line</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="template" className="text-right">
                Template
              </Label>
              <Select value={formData.template} onValueChange={handleTemplateSelect}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Choose a template (optional)" />
                </SelectTrigger>
                <SelectContent>
                  {messageTemplates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="message" className="text-right mt-2">
                Message
              </Label>
              <div className="col-span-3 space-y-2">
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Type your message here..."
                  className="min-h-[100px]"
                  required
                />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{getMessageLength()}/160 characters</span>
                  <div className="flex space-x-2">
                    <Badge variant="outline">
                      {getSegmentCount()} segment{getSegmentCount() !== 1 ? "s" : ""}
                    </Badge>
                    <Badge variant="outline">~${getEstimatedCost()}</Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isSending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSending}>
              {isSending ? (
                <>
                  <MessageSquare className="mr-2 h-4 w-4 animate-pulse" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Send Message
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
