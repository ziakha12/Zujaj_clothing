"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Plus, Copy, Edit, Trash2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const templates = [
  {
    id: "1",
    name: "Welcome Message",
    content: "Welcome to our service! We're excited to have you on board.",
    category: "Onboarding",
    usageCount: 45,
  },
  {
    id: "2",
    name: "Appointment Reminder",
    content: "This is a reminder about your appointment tomorrow at [TIME]. Please reply to confirm.",
    category: "Reminders",
    usageCount: 123,
  },
  {
    id: "3",
    name: "Follow-up",
    content: "Thank you for your inquiry. Our team will get back to you within 24 hours.",
    category: "Sales",
    usageCount: 67,
  },
  {
    id: "4",
    name: "Support Response",
    content: "We've received your support request and are working on it. We'll update you soon.",
    category: "Support",
    usageCount: 89,
  },
  {
    id: "5",
    name: "Payment Reminder",
    content: "Your payment of $[AMOUNT] is due on [DATE]. Please make your payment to avoid any service interruption.",
    category: "Billing",
    usageCount: 34,
  },
  {
    id: "6",
    name: "Order Confirmation",
    content: "Your order #[ORDER_ID] has been confirmed and will be shipped within 2-3 business days.",
    category: "Orders",
    usageCount: 156,
  },
]

export function MessageTemplates() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = ["all", ...Array.from(new Set(templates.map((t) => t.category)))]

  const filteredTemplates =
    selectedCategory === "all" ? templates : templates.filter((t) => t.category === selectedCategory)

  const getCategoryColor = (category: string) => {
    const colors = {
      Onboarding: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
      Reminders: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
      Sales: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
      Support: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
      Billing: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
      Orders: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300",
    }
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Message Templates</CardTitle>
            <CardDescription>Quick access to common messages</CardDescription>
          </div>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="capitalize"
              >
                {category}
              </Button>
            ))}
          </div>

          <ScrollArea className="h-[400px]">
            <div className="space-y-3">
              {filteredTemplates.map((template) => (
                <div key={template.id} className="border rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-sm">{template.name}</h4>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <span className="sr-only">Open menu</span>
                          <Edit className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Copy className="mr-2 h-4 w-4" />
                          Copy
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <p className="text-xs text-muted-foreground line-clamp-2">{template.content}</p>

                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className={getCategoryColor(template.category)}>
                      {template.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Used {template.usageCount} times</span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  )
}
