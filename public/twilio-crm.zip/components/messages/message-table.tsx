"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MoreHorizontal, Search, Filter, Reply, Forward, Eye } from "lucide-react"
import { MessageDetailsDialog } from "./message-details-dialog"

// Mock data for messages
const messages = [
  {
    id: "1",
    phoneNumber: "+1 (555) 123-4567",
    direction: "Outbound",
    status: "Delivered",
    content: "Thank you for your inquiry. Our team will get back to you within 24 hours.",
    timestamp: "2024-01-15 14:30:00",
    agent: "John Doe",
    cost: "$0.0075",
    segments: 1,
  },
  {
    id: "2",
    phoneNumber: "+1 (555) 987-6543",
    direction: "Inbound",
    status: "Received",
    content: "Hi, I'm interested in your pricing plans. Can you send me more information?",
    timestamp: "2024-01-15 13:15:00",
    agent: "Sarah Wilson",
    cost: "$0.00",
    segments: 1,
  },
  {
    id: "3",
    phoneNumber: "+1 (555) 456-7890",
    direction: "Outbound",
    status: "Failed",
    content: "Your appointment is confirmed for tomorrow at 2 PM. Please reply to confirm.",
    timestamp: "2024-01-15 12:00:00",
    agent: "Mike Johnson",
    cost: "$0.00",
    segments: 1,
  },
  {
    id: "4",
    phoneNumber: "+1 (555) 234-5678",
    direction: "Inbound",
    status: "Received",
    content: "Yes, I confirm my appointment for tomorrow at 2 PM. Thank you!",
    timestamp: "2024-01-15 11:45:00",
    agent: "Emily Davis",
    cost: "$0.00",
    segments: 1,
  },
  {
    id: "5",
    phoneNumber: "+1 (555) 345-6789",
    direction: "Outbound",
    status: "Pending",
    content:
      "Welcome to our service! Your account has been successfully created. Login details have been sent to your email.",
    timestamp: "2024-01-15 10:30:00",
    agent: "David Brown",
    cost: "$0.015",
    segments: 2,
  },
]

export function MessageTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [directionFilter, setDirectionFilter] = useState("all")
  const [selectedMessage, setSelectedMessage] = useState<(typeof messages)[0] | null>(null)

  const filteredMessages = messages.filter((message) => {
    const matchesSearch =
      message.phoneNumber.includes(searchTerm) ||
      message.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.agent.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || message.status.toLowerCase() === statusFilter
    const matchesDirection = directionFilter === "all" || message.direction.toLowerCase() === directionFilter

    return matchesSearch && matchesStatus && matchesDirection
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Delivered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "Received":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const getDirectionColor = (direction: string) => {
    return direction === "Inbound"
      ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      : "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
  }

  const truncateMessage = (content: string, maxLength = 50) => {
    return content.length > maxLength ? content.substring(0, maxLength) + "..." : content
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Message History</CardTitle>
        <CardDescription>All SMS messages sent and received</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="received">Received</SelectItem>
            </SelectContent>
          </Select>
          <Select value={directionFilter} onValueChange={setDirectionFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Direction" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Messages</SelectItem>
              <SelectItem value="inbound">Inbound</SelectItem>
              <SelectItem value="outbound">Outbound</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Phone Number</TableHead>
                <TableHead>Direction</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Message</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMessages.map((message) => (
                <TableRow key={message.id}>
                  <TableCell className="font-medium">{message.phoneNumber}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getDirectionColor(message.direction)}>
                      {message.direction}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(message.status)}>
                      {message.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs">
                    <span className="text-sm">{truncateMessage(message.content)}</span>
                  </TableCell>
                  <TableCell>{message.agent}</TableCell>
                  <TableCell>{new Date(message.timestamp).toLocaleString()}</TableCell>
                  <TableCell>{message.cost}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => setSelectedMessage(message)}>
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Reply className="mr-2 h-4 w-4" />
                          Reply
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Forward className="mr-2 h-4 w-4" />
                          Forward
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Add to Contact</DropdownMenuItem>
                        <DropdownMenuItem>Create Template</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {selectedMessage && (
          <MessageDetailsDialog
            message={selectedMessage}
            open={!!selectedMessage}
            onOpenChange={(open) => !open && setSelectedMessage(null)}
          />
        )}
      </CardContent>
    </Card>
  )
}
