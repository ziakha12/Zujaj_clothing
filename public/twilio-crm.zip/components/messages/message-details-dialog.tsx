"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Reply, Forward, MessageSquare, Clock, User, DollarSign, Hash } from "lucide-react"

interface Message {
  id: string
  phoneNumber: string
  direction: string
  status: string
  content: string
  timestamp: string
  agent: string
  cost: string
  segments: number
}

interface MessageDetailsDialogProps {
  message: Message
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function MessageDetailsDialog({ message, open, onOpenChange }: MessageDetailsDialogProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Delivered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "Received":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const getDirectionColor = (direction: string) => {
    return direction === "Inbound"
      ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      : "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Message Details</DialogTitle>
          <DialogDescription>Complete information about this message</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{message.phoneNumber}</span>
            </div>
            <div className="flex space-x-2">
              <Badge variant="secondary" className={getDirectionColor(message.direction)}>
                {message.direction}
              </Badge>
              <Badge variant="secondary" className={getStatusColor(message.status)}>
                {message.status}
              </Badge>
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium mb-2">Message Content</p>
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-sm">{message.content}</p>
              </div>
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Timestamp</p>
                  <p className="text-sm text-muted-foreground">{new Date(message.timestamp).toLocaleString()}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Agent</p>
                  <p className="text-sm text-muted-foreground">{message.agent}</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Cost</p>
                  <p className="text-sm text-muted-foreground">{message.cost}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Hash className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Segments</p>
                  <p className="text-sm text-muted-foreground">{message.segments}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <Reply className="mr-2 h-4 w-4" />
              Reply
            </Button>
            <Button variant="outline" size="sm">
              <Forward className="mr-2 h-4 w-4" />
              Forward
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
