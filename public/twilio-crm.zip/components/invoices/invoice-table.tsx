"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MoreHorizontal, Search, Filter, Eye, Download, Send, Edit } from "lucide-react"
import { InvoiceDetailsDialog } from "./invoice-details-dialog"

// Mock data for invoices
const invoices = [
  {
    id: "INV-001",
    clientName: "Acme Corporation",
    clientEmail: "billing@acme.com",
    amount: "$2,500.00",
    status: "Paid",
    issueDate: "2024-01-15",
    dueDate: "2024-02-15",
    paidDate: "2024-01-20",
    description: "Twilio communication services - January 2024",
    items: [
      { description: "SMS Messages (1,000 messages)", quantity: 1, rate: 750, amount: 750 },
      { description: "Voice Calls (500 minutes)", quantity: 1, rate: 1250, amount: 1250 },
      { description: "Phone Number Rental", quantity: 2, rate: 250, amount: 500 },
    ],
  },
  {
    id: "INV-002",
    clientName: "TechStart Inc.",
    clientEmail: "finance@techstart.com",
    amount: "$1,850.00",
    status: "Pending",
    issueDate: "2024-01-10",
    dueDate: "2024-02-10",
    paidDate: null,
    description: "Monthly communication package",
    items: [
      { description: "SMS Messages (750 messages)", quantity: 1, rate: 562.5, amount: 562.5 },
      { description: "Voice Calls (300 minutes)", quantity: 1, rate: 750, amount: 750 },
      { description: "Phone Number Rental", quantity: 2, rate: 268.75, amount: 537.5 },
    ],
  },
  {
    id: "INV-003",
    clientName: "Global Solutions Ltd",
    clientEmail: "accounts@globalsolutions.com",
    amount: "$3,200.00",
    status: "Overdue",
    issueDate: "2023-12-15",
    dueDate: "2024-01-15",
    paidDate: null,
    description: "Q4 2023 communication services",
    items: [
      { description: "SMS Messages (1,500 messages)", quantity: 1, rate: 1125, amount: 1125 },
      { description: "Voice Calls (800 minutes)", quantity: 1, rate: 2000, amount: 2000 },
      { description: "Premium Support", quantity: 1, rate: 75, amount: 75 },
    ],
  },
  {
    id: "INV-004",
    clientName: "StartupXYZ",
    clientEmail: "billing@startupxyz.com",
    amount: "$950.00",
    status: "Draft",
    issueDate: "2024-01-16",
    dueDate: "2024-02-16",
    paidDate: null,
    description: "Basic communication package",
    items: [
      { description: "SMS Messages (400 messages)", quantity: 1, rate: 300, amount: 300 },
      { description: "Voice Calls (200 minutes)", quantity: 1, rate: 500, amount: 500 },
      { description: "Phone Number Rental", quantity: 1, rate: 150, amount: 150 },
    ],
  },
  {
    id: "INV-005",
    clientName: "Enterprise Corp",
    clientEmail: "payments@enterprise.com",
    amount: "$5,750.00",
    status: "Sent",
    issueDate: "2024-01-12",
    dueDate: "2024-02-12",
    paidDate: null,
    description: "Enterprise communication solution",
    items: [
      { description: "SMS Messages (2,500 messages)", quantity: 1, rate: 1875, amount: 1875 },
      { description: "Voice Calls (1,200 minutes)", quantity: 1, rate: 3000, amount: 3000 },
      { description: "Dedicated Phone Numbers", quantity: 5, rate: 175, amount: 875 },
    ],
  },
]

export function InvoiceTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedInvoice, setSelectedInvoice] = useState<(typeof invoices)[0] | null>(null)

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch =
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.clientEmail.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || invoice.status.toLowerCase() === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Paid":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Overdue":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "Sent":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "Draft":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Invoice History</CardTitle>
        <CardDescription>Manage all your invoices and track payments</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search invoices..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="sent">Sent</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice ID</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-medium">{invoice.id}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{invoice.clientName}</div>
                      <div className="text-sm text-muted-foreground">{invoice.clientEmail}</div>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{invoice.amount}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(invoice.status)}>
                      {invoice.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{invoice.issueDate}</TableCell>
                  <TableCell>{invoice.dueDate}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => setSelectedInvoice(invoice)}>
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit Invoice
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Download PDF
                        </DropdownMenuItem>
                        {invoice.status !== "Paid" && (
                          <DropdownMenuItem>
                            <Send className="mr-2 h-4 w-4" />
                            Send Invoice
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Duplicate</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {selectedInvoice && (
          <InvoiceDetailsDialog
            invoice={selectedInvoice}
            open={!!selectedInvoice}
            onOpenChange={(open) => !open && setSelectedInvoice(null)}
          />
        )}
      </CardContent>
    </Card>
  )
}
