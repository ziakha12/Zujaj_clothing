"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Play, Download, Phone, Clock, User, DollarSign, FileText } from "lucide-react"

interface Call {
  id: string
  phoneNumber: string
  direction: string
  status: string
  duration: string
  startTime: string
  endTime: string
  agent: string
  cost: string
  recording: boolean
  notes: string
}

interface CallDetailsDialogProps {
  call: Call
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CallDetailsDialog({ call, open, onOpenChange }: CallDetailsDialogProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Busy":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const getDirectionColor = (direction: string) => {
    return direction === "Inbound"
      ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      : "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Call Details</DialogTitle>
          <DialogDescription>Complete information about this call</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{call.phoneNumber}</span>
            </div>
            <div className="flex space-x-2">
              <Badge variant="secondary" className={getDirectionColor(call.direction)}>
                {call.direction}
              </Badge>
              <Badge variant="secondary" className={getStatusColor(call.status)}>
                {call.status}
              </Badge>
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Duration</p>
                  <p className="text-sm text-muted-foreground">{call.duration}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Agent</p>
                  <p className="text-sm text-muted-foreground">{call.agent}</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Cost</p>
                  <p className="text-sm text-muted-foreground">{call.cost}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Recording</p>
                  <p className="text-sm text-muted-foreground">{call.recording ? "Available" : "Not recorded"}</p>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium mb-2">Call Timeline</p>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Started: {new Date(call.startTime).toLocaleString()}</p>
              <p>Ended: {new Date(call.endTime).toLocaleString()}</p>
            </div>
          </div>

          {call.notes && (
            <>
              <Separator />
              <div>
                <p className="text-sm font-medium mb-2">Notes</p>
                <p className="text-sm text-muted-foreground">{call.notes}</p>
              </div>
            </>
          )}

          {call.recording && (
            <>
              <Separator />
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">
                  <Play className="mr-2 h-4 w-4" />
                  Play Recording
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button>
            <Phone className="mr-2 h-4 w-4" />
            Call Back
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
