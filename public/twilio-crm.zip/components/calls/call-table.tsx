"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MoreHorizontal, Search, Filter, Play, Download, Eye } from "lucide-react"
import { CallDetailsDialog } from "./call-details-dialog"

// Mock data for calls
const calls = [
  {
    id: "1",
    phoneNumber: "+1 (555) 123-4567",
    direction: "Outbound",
    status: "Completed",
    duration: "5:23",
    startTime: "2024-01-15 14:30:00",
    endTime: "2024-01-15 14:35:23",
    agent: "John Doe",
    cost: "$0.12",
    recording: true,
    notes: "Customer inquiry about pricing",
  },
  {
    id: "2",
    phoneNumber: "+1 (555) 987-6543",
    direction: "Inbound",
    status: "Completed",
    duration: "12:45",
    startTime: "2024-01-15 13:15:00",
    endTime: "2024-01-15 13:27:45",
    agent: "Sarah Wilson",
    cost: "$0.28",
    recording: true,
    notes: "Support ticket resolution",
  },
  {
    id: "3",
    phoneNumber: "+1 (555) 456-7890",
    direction: "Outbound",
    status: "Failed",
    duration: "0:00",
    startTime: "2024-01-15 12:00:00",
    endTime: "2024-01-15 12:00:00",
    agent: "Mike Johnson",
    cost: "$0.00",
    recording: false,
    notes: "No answer",
  },
  {
    id: "4",
    phoneNumber: "+1 (555) 234-5678",
    direction: "Inbound",
    status: "Completed",
    duration: "8:12",
    startTime: "2024-01-15 11:45:00",
    endTime: "2024-01-15 11:53:12",
    agent: "Emily Davis",
    cost: "$0.18",
    recording: true,
    notes: "New customer onboarding",
  },
  {
    id: "5",
    phoneNumber: "+1 (555) 345-6789",
    direction: "Outbound",
    status: "Busy",
    duration: "0:00",
    startTime: "2024-01-15 10:30:00",
    endTime: "2024-01-15 10:30:00",
    agent: "David Brown",
    cost: "$0.00",
    recording: false,
    notes: "Line busy",
  },
]

export function CallTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [directionFilter, setDirectionFilter] = useState("all")
  const [selectedCall, setSelectedCall] = useState<(typeof calls)[0] | null>(null)

  const filteredCalls = calls.filter((call) => {
    const matchesSearch =
      call.phoneNumber.includes(searchTerm) || call.agent.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || call.status.toLowerCase() === statusFilter
    const matchesDirection = directionFilter === "all" || call.direction.toLowerCase() === directionFilter

    return matchesSearch && matchesStatus && matchesDirection
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Busy":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "No Answer":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const getDirectionColor = (direction: string) => {
    return direction === "Inbound"
      ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      : "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Call History</CardTitle>
        <CardDescription>Complete log of all calls made and received</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search calls..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="busy">Busy</SelectItem>
            </SelectContent>
          </Select>
          <Select value={directionFilter} onValueChange={setDirectionFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Direction" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Calls</SelectItem>
              <SelectItem value="inbound">Inbound</SelectItem>
              <SelectItem value="outbound">Outbound</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Phone Number</TableHead>
                <TableHead>Direction</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Start Time</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCalls.map((call) => (
                <TableRow key={call.id}>
                  <TableCell className="font-medium">{call.phoneNumber}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getDirectionColor(call.direction)}>
                      {call.direction}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(call.status)}>
                      {call.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{call.duration}</TableCell>
                  <TableCell>{call.agent}</TableCell>
                  <TableCell>{new Date(call.startTime).toLocaleString()}</TableCell>
                  <TableCell>{call.cost}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => setSelectedCall(call)}>
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        {call.recording && (
                          <>
                            <DropdownMenuItem>
                              <Play className="mr-2 h-4 w-4" />
                              Play Recording
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download Recording
                            </DropdownMenuItem>
                          </>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Call Back</DropdownMenuItem>
                        <DropdownMenuItem>Add to Contact</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {selectedCall && (
          <CallDetailsDialog
            call={selectedCall}
            open={!!selectedCall}
            onOpenChange={(open) => !open && setSelectedCall(null)}
          />
        )}
      </CardContent>
    </Card>
  )
}
