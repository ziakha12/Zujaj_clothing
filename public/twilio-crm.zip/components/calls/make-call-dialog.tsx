"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Phone, PhoneCall } from "lucide-react"

interface MakeCallDialogProps {
  children: React.ReactNode
}

export function MakeCallDialog({ children }: MakeCallDialogProps) {
  const [open, setOpen] = useState(false)
  const [isDialing, setIsDialing] = useState(false)
  const [formData, setFormData] = useState({
    phoneNumber: "",
    fromNumber: "",
    recordCall: true,
    notes: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsDialing(true)

    // Simulate call initiation
    setTimeout(() => {
      console.log("Making call:", formData)
      setIsDialing(false)
      setOpen(false)
      setFormData({
        phoneNumber: "",
        fromNumber: "",
        recordCall: true,
        notes: "",
      })
    }, 2000)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Make New Call</DialogTitle>
          <DialogDescription>Enter the phone number and call details to initiate a new call.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone-number" className="text-right">
                To Number
              </Label>
              <Input
                id="phone-number"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="from-number" className="text-right">
                From Number
              </Label>
              <Select
                value={formData.fromNumber}
                onValueChange={(value) => setFormData({ ...formData, fromNumber: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select caller ID" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="+15551234567">+1 (555) 123-4567 - Main Line</SelectItem>
                  <SelectItem value="+15559876543">+1 (555) 987-6543 - Sales Line</SelectItem>
                  <SelectItem value="+15555555555">+1 (555) 555-5555 - Support Line</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-4">
              <Label htmlFor="record-call" className="text-sm font-medium">
                Record Call
              </Label>
              <Switch
                id="record-call"
                checked={formData.recordCall}
                onCheckedChange={(checked) => setFormData({ ...formData, recordCall: checked })}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="call-notes" className="text-right">
                Notes
              </Label>
              <Textarea
                id="call-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="col-span-3"
                placeholder="Call purpose or notes..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isDialing}>
              Cancel
            </Button>
            <Button type="submit" disabled={isDialing}>
              {isDialing ? (
                <>
                  <PhoneCall className="mr-2 h-4 w-4 animate-pulse" />
                  Dialing...
                </>
              ) : (
                <>
                  <Phone className="mr-2 h-4 w-4" />
                  Make Call
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
