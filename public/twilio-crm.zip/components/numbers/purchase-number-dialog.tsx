"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, ShoppingCart, RefreshCw } from "lucide-react"

interface PurchaseNumberDialogProps {
  children: React.ReactNode
}

// Mock available numbers from Twilio
const availableNumbers = [
  {
    phoneNumber: "+1 (555) 111-2222",
    locality: "New York",
    region: "NY",
    capabilities: ["Voice", "SMS"],
    monthlyPrice: "$3.00",
    setupFee: "$1.00",
  },
  {
    phoneNumber: "+1 (555) 333-4444",
    locality: "Los Angeles",
    region: "CA",
    capabilities: ["Voice", "SMS", "MMS"],
    monthlyPrice: "$3.00",
    setupFee: "$1.00",
  },
  {
    phoneNumber: "+1 (555) 555-6666",
    locality: "Chicago",
    region: "IL",
    capabilities: ["Voice", "SMS"],
    monthlyPrice: "$3.00",
    setupFee: "$1.00",
  },
  {
    phoneNumber: "+1 (555) 777-8888",
    locality: "Miami",
    region: "FL",
    capabilities: ["Voice", "SMS", "MMS"],
    monthlyPrice: "$3.00",
    setupFee: "$1.00",
  },
  {
    phoneNumber: "+1 (555) 999-0000",
    locality: "Seattle",
    region: "WA",
    capabilities: ["Voice", "SMS"],
    monthlyPrice: "$3.00",
    setupFee: "$1.00",
  },
]

export function PurchaseNumberDialog({ children }: PurchaseNumberDialogProps) {
  const [open, setOpen] = useState(false)
  const [searchCriteria, setSearchCriteria] = useState({
    areaCode: "",
    locality: "",
    contains: "",
    voiceEnabled: true,
    smsEnabled: true,
    mmsEnabled: false,
  })
  const [selectedNumber, setSelectedNumber] = useState<(typeof availableNumbers)[0] | null>(null)
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = () => {
    setIsSearching(true)
    // Simulate API call
    setTimeout(() => {
      setIsSearching(false)
    }, 1000)
  }

  const handlePurchase = () => {
    if (selectedNumber) {
      console.log("Purchasing number:", selectedNumber)
      setOpen(false)
      setSelectedNumber(null)
      // Reset form
      setSearchCriteria({
        areaCode: "",
        locality: "",
        contains: "",
        voiceEnabled: true,
        smsEnabled: true,
        mmsEnabled: false,
      })
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Purchase Phone Number</DialogTitle>
          <DialogDescription>Search and purchase a new Twilio phone number</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Search Criteria */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Search Criteria</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="area-code">Area Code</Label>
                  <Input
                    id="area-code"
                    placeholder="555"
                    value={searchCriteria.areaCode}
                    onChange={(e) => setSearchCriteria({ ...searchCriteria, areaCode: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="locality">City/Locality</Label>
                  <Select
                    value={searchCriteria.locality}
                    onValueChange={(value) => setSearchCriteria({ ...searchCriteria, locality: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select city" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new-york">New York, NY</SelectItem>
                      <SelectItem value="los-angeles">Los Angeles, CA</SelectItem>
                      <SelectItem value="chicago">Chicago, IL</SelectItem>
                      <SelectItem value="miami">Miami, FL</SelectItem>
                      <SelectItem value="seattle">Seattle, WA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="contains">Contains Digits</Label>
                <Input
                  id="contains"
                  placeholder="e.g., 1234"
                  value={searchCriteria.contains}
                  onChange={(e) => setSearchCriteria({ ...searchCriteria, contains: e.target.value })}
                />
              </div>

              <div className="space-y-3">
                <Label>Required Capabilities</Label>
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="voice"
                      checked={searchCriteria.voiceEnabled}
                      onCheckedChange={(checked) =>
                        setSearchCriteria({ ...searchCriteria, voiceEnabled: checked as boolean })
                      }
                    />
                    <Label htmlFor="voice">Voice</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="sms"
                      checked={searchCriteria.smsEnabled}
                      onCheckedChange={(checked) =>
                        setSearchCriteria({ ...searchCriteria, smsEnabled: checked as boolean })
                      }
                    />
                    <Label htmlFor="sms">SMS</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="mms"
                      checked={searchCriteria.mmsEnabled}
                      onCheckedChange={(checked) =>
                        setSearchCriteria({ ...searchCriteria, mmsEnabled: checked as boolean })
                      }
                    />
                    <Label htmlFor="mms">MMS</Label>
                  </div>
                </div>
              </div>

              <Button onClick={handleSearch} disabled={isSearching} className="w-full">
                {isSearching ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Search Available Numbers
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Available Numbers */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Available Numbers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {availableNumbers.map((number) => (
                  <div
                    key={number.phoneNumber}
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      selectedNumber?.phoneNumber === number.phoneNumber
                        ? "border-primary bg-primary/5"
                        : "hover:border-muted-foreground/50"
                    }`}
                    onClick={() => setSelectedNumber(number)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="font-medium">{number.phoneNumber}</div>
                        <div className="text-sm text-muted-foreground">
                          {number.locality}, {number.region}
                        </div>
                        <div className="flex space-x-1">
                          {number.capabilities.map((capability) => (
                            <Badge key={capability} variant="outline" className="text-xs">
                              {capability}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{number.monthlyPrice}/month</div>
                        <div className="text-sm text-muted-foreground">Setup: {number.setupFee}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handlePurchase} disabled={!selectedNumber}>
            <ShoppingCart className="mr-2 h-4 w-4" />
            Purchase Number
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
