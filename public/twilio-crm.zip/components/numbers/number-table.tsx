"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MoreHorizontal, Search, Filter, Settings, UserPlus, Trash2, BarChart3 } from "lucide-react"
import { AssignNumberDialog } from "./assign-number-dialog"
import { NumberDetailsDialog } from "./number-details-dialog"

// Mock data for phone numbers
const phoneNumbers = [
  {
    id: "1",
    phoneNumber: "+1 (555) 123-4567",
    friendlyName: "Main Sales Line",
    assignedTo: "John Doe",
    assignedToEmail: "john@company.com",
    status: "Active",
    capabilities: ["Voice", "SMS"],
    purchaseDate: "2024-01-01",
    monthlyCost: "$3.00",
    usage: {
      calls: 145,
      messages: 89,
    },
    location: "New York, NY",
  },
  {
    id: "2",
    phoneNumber: "+1 (555) 987-6543",
    friendlyName: "Support Hotline",
    assignedTo: "Sarah Wilson",
    assignedToEmail: "sarah@company.com",
    status: "Active",
    capabilities: ["Voice", "SMS"],
    purchaseDate: "2024-01-05",
    monthlyCost: "$3.00",
    usage: {
      calls: 234,
      messages: 156,
    },
    location: "Los Angeles, CA",
  },
  {
    id: "3",
    phoneNumber: "+1 (555) 456-7890",
    friendlyName: "Marketing Campaign",
    assignedTo: null,
    assignedToEmail: null,
    status: "Available",
    capabilities: ["Voice", "SMS"],
    purchaseDate: "2024-01-10",
    monthlyCost: "$3.00",
    usage: {
      calls: 0,
      messages: 0,
    },
    location: "Chicago, IL",
  },
  {
    id: "4",
    phoneNumber: "+1 (555) 234-5678",
    friendlyName: "Customer Service",
    assignedTo: "Mike Johnson",
    assignedToEmail: "mike@company.com",
    status: "Active",
    capabilities: ["Voice", "SMS", "MMS"],
    purchaseDate: "2023-12-15",
    monthlyCost: "$3.00",
    usage: {
      calls: 189,
      messages: 267,
    },
    location: "Miami, FL",
  },
  {
    id: "5",
    phoneNumber: "+1 (555) 345-6789",
    friendlyName: "Emergency Line",
    assignedTo: "Emily Davis",
    assignedToEmail: "emily@company.com",
    status: "Suspended",
    capabilities: ["Voice"],
    purchaseDate: "2024-01-08",
    monthlyCost: "$3.00",
    usage: {
      calls: 12,
      messages: 0,
    },
    location: "Seattle, WA",
  },
]

export function NumberTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedNumber, setSelectedNumber] = useState<(typeof phoneNumbers)[0] | null>(null)
  const [assignDialogOpen, setAssignDialogOpen] = useState(false)
  const [numberToAssign, setNumberToAssign] = useState<(typeof phoneNumbers)[0] | null>(null)

  const filteredNumbers = phoneNumbers.filter((number) => {
    const matchesSearch =
      number.phoneNumber.includes(searchTerm) ||
      number.friendlyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (number.assignedTo && number.assignedTo.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesStatus = statusFilter === "all" || number.status.toLowerCase() === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Available":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "Suspended":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const handleAssignNumber = (number: (typeof phoneNumbers)[0]) => {
    setNumberToAssign(number)
    setAssignDialogOpen(true)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Phone Number Management</CardTitle>
        <CardDescription>Manage your Twilio phone numbers and assignments</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search numbers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Phone Number</TableHead>
                <TableHead>Friendly Name</TableHead>
                <TableHead>Assigned To</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Capabilities</TableHead>
                <TableHead>Usage</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredNumbers.map((number) => (
                <TableRow key={number.id}>
                  <TableCell className="font-medium">{number.phoneNumber}</TableCell>
                  <TableCell>{number.friendlyName}</TableCell>
                  <TableCell>
                    {number.assignedTo ? (
                      <div>
                        <div className="font-medium">{number.assignedTo}</div>
                        <div className="text-sm text-muted-foreground">{number.assignedToEmail}</div>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">Unassigned</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(number.status)}>
                      {number.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-1">
                      {number.capabilities.map((capability) => (
                        <Badge key={capability} variant="outline" className="text-xs">
                          {capability}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{number.usage.calls} calls</div>
                      <div>{number.usage.messages} messages</div>
                    </div>
                  </TableCell>
                  <TableCell>{number.monthlyCost}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => setSelectedNumber(number)}>
                          <BarChart3 className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAssignNumber(number)}>
                          <UserPlus className="mr-2 h-4 w-4" />
                          {number.assignedTo ? "Reassign" : "Assign"} Number
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Settings className="mr-2 h-4 w-4" />
                          Configure
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Release Number
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {selectedNumber && (
          <NumberDetailsDialog
            number={selectedNumber}
            open={!!selectedNumber}
            onOpenChange={(open) => !open && setSelectedNumber(null)}
          />
        )}

        {numberToAssign && (
          <AssignNumberDialog
            number={numberToAssign}
            open={assignDialogOpen}
            onOpenChange={(open) => {
              setAssignDialogOpen(open)
              if (!open) setNumberToAssign(null)
            }}
          />
        )}
      </CardContent>
    </Card>
  )
}
