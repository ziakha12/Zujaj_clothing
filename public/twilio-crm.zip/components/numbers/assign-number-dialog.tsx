"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { UserPlus } from "lucide-react"

interface PhoneNumber {
  id: string
  phoneNumber: string
  friendlyName: string
  assignedTo: string | null
  assignedToEmail: string | null
}

interface AssignNumberDialogProps {
  number: PhoneNumber
  open: boolean
  onOpenChange: (open: boolean) => void
}

// Mock users data
const users = [
  { id: "1", name: "John Doe", email: "john@company.com", department: "Sales" },
  { id: "2", name: "Sarah Wilson", email: "sarah@company.com", department: "Support" },
  { id: "3", name: "Mike Johnson", email: "mike@company.com", department: "Support" },
  { id: "4", name: "Emily Davis", email: "emily@company.com", department: "Sales" },
  { id: "5", name: "David Brown", email: "david@company.com", department: "Marketing" },
]

export function AssignNumberDialog({ number, open, onOpenChange }: AssignNumberDialogProps) {
  const [formData, setFormData] = useState({
    assignedUser: "",
    friendlyName: number.friendlyName,
    notes: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Assigning number:", { number: number.phoneNumber, ...formData })
    onOpenChange(false)
    // Reset form
    setFormData({
      assignedUser: "",
      friendlyName: number.friendlyName,
      notes: "",
    })
  }

  const selectedUser = users.find((user) => user.id === formData.assignedUser)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{number.assignedTo ? "Reassign" : "Assign"} Phone Number</DialogTitle>
          <DialogDescription>
            {number.assignedTo ? "Reassign" : "Assign"} {number.phoneNumber} to a user
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Phone Number</Label>
              <div className="text-sm font-medium p-2 bg-muted rounded">{number.phoneNumber}</div>
            </div>

            {number.assignedTo && (
              <div className="space-y-2">
                <Label>Currently Assigned To</Label>
                <div className="text-sm p-2 bg-muted rounded">
                  <div className="font-medium">{number.assignedTo}</div>
                  <div className="text-muted-foreground">{number.assignedToEmail}</div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="assigned-user" className="text-right">
                Assign To
              </Label>
              <Select
                value={formData.assignedUser}
                onValueChange={(value) => setFormData({ ...formData, assignedUser: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select a user" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      <div>
                        <div className="font-medium">{user.name}</div>
                        <div className="text-sm text-muted-foreground">{user.email}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedUser && (
              <div className="space-y-2">
                <Label>Selected User</Label>
                <div className="text-sm p-2 bg-primary/5 border border-primary/20 rounded">
                  <div className="font-medium">{selectedUser.name}</div>
                  <div className="text-muted-foreground">{selectedUser.email}</div>
                  <div className="text-muted-foreground">{selectedUser.department} Department</div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="friendly-name" className="text-right">
                Friendly Name
              </Label>
              <Input
                id="friendly-name"
                value={formData.friendlyName}
                onChange={(e) => setFormData({ ...formData, friendlyName: e.target.value })}
                className="col-span-3"
                placeholder="e.g., Sales Line, Support Hotline"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                Notes
              </Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="col-span-3"
                placeholder="Additional notes about this assignment..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!formData.assignedUser}>
              <UserPlus className="mr-2 h-4 w-4" />
              {number.assignedTo ? "Reassign" : "Assign"} Number
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
