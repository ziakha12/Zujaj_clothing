"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Upload, AlertCircle } from "lucide-react"

interface CsvFile {
  file: File
  data: string[][]
  headers: string[]
}

interface ColumnMappingProps {
  csvFile: CsvFile
  importType: string
  onBack: () => void
  onImport: () => void
}

const fieldMappings = {
  contacts: [
    { key: "name", label: "Name", required: true },
    { key: "email", label: "Email", required: false },
    { key: "phone", label: "Phone", required: true },
    { key: "company", label: "Company", required: false },
    { key: "address", label: "Address", required: false },
    { key: "notes", label: "Notes", required: false },
  ],
  users: [
    { key: "name", label: "Name", required: true },
    { key: "email", label: "Email", required: true },
    { key: "phone", label: "Phone", required: false },
    { key: "role", label: "Role", required: true },
    { key: "department", label: "Department", required: false },
  ],
  "call-logs": [
    { key: "phone_number", label: "Phone Number", required: true },
    { key: "direction", label: "Direction", required: true },
    { key: "duration", label: "Duration", required: false },
    { key: "status", label: "Status", required: true },
    { key: "start_time", label: "Start Time", required: true },
    { key: "agent", label: "Agent", required: false },
  ],
  messages: [
    { key: "phone_number", label: "Phone Number", required: true },
    { key: "direction", label: "Direction", required: true },
    { key: "content", label: "Message Content", required: true },
    { key: "timestamp", label: "Timestamp", required: true },
    { key: "status", label: "Status", required: false },
    { key: "agent", label: "Agent", required: false },
  ],
  invoices: [
    { key: "client_name", label: "Client Name", required: true },
    { key: "client_email", label: "Client Email", required: true },
    { key: "amount", label: "Amount", required: true },
    { key: "status", label: "Status", required: true },
    { key: "issue_date", label: "Issue Date", required: true },
    { key: "due_date", label: "Due Date", required: true },
  ],
}

export function ColumnMapping({ csvFile, importType, onBack, onImport }: ColumnMappingProps) {
  const [mappings, setMappings] = useState<Record<string, string>>({})

  const fields = fieldMappings[importType as keyof typeof fieldMappings] || []
  const requiredFields = fields.filter((field) => field.required)
  const mappedRequiredFields = requiredFields.filter((field) => mappings[field.key])
  const canImport = mappedRequiredFields.length === requiredFields.length

  const handleMappingChange = (fieldKey: string, csvColumn: string) => {
    setMappings((prev) => ({
      ...prev,
      [fieldKey]: csvColumn,
    }))
  }

  const getPreviewValue = (fieldKey: string) => {
    const csvColumn = mappings[fieldKey]
    if (!csvColumn) return "Not mapped"

    const columnIndex = csvFile.headers.indexOf(csvColumn)
    if (columnIndex === -1) return "Column not found"

    const firstRow = csvFile.data[0]
    return firstRow?.[columnIndex] || "No data"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Map CSV Columns</CardTitle>
        <CardDescription>
          Map your CSV columns to the appropriate fields for {importType.replace("-", " ")}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4">
          {fields.map((field) => (
            <div key={field.key} className="grid grid-cols-3 gap-4 items-center">
              <div className="space-y-1">
                <Label className="flex items-center space-x-2">
                  <span>{field.label}</span>
                  {field.required && <Badge variant="destructive">Required</Badge>}
                </Label>
              </div>
              <div>
                <Select
                  value={mappings[field.key] || "none"}
                  onValueChange={(value) => handleMappingChange(field.key, value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select CSV column" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Don't import</SelectItem>
                    {csvFile.headers.map((header) => (
                      <SelectItem key={header} value={header}>
                        {header}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="text-sm text-muted-foreground">
                Preview: <span className="font-medium">{getPreviewValue(field.key)}</span>
              </div>
            </div>
          ))}
        </div>

        {!canImport && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please map all required fields before importing. Missing:{" "}
              {requiredFields
                .filter((field) => !mappings[field.key])
                .map((field) => field.label)
                .join(", ")}
            </AlertDescription>
          </Alert>
        )}

        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <Button onClick={onImport} disabled={!canImport}>
            <Upload className="mr-2 h-4 w-4" />
            Import {csvFile.data.length} Records
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
