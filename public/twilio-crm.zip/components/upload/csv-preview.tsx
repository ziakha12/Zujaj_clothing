"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { ArrowLeft, ArrowRight, FileText } from "lucide-react"

interface CsvFile {
  file: File
  data: string[][]
  headers: string[]
}

interface CsvPreviewProps {
  csvFile: CsvFile
  importType: string
  onImportTypeChange: (type: string) => void
  onBack: () => void
  onNext: () => void
}

export function CsvPreview({ csvFile, importType, onImportTypeChange, onBack, onNext }: CsvPreviewProps) {
  const previewRows = csvFile.data.slice(0, 5) // Show first 5 rows

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="h-5 w-5" />
          <span>CSV Preview</span>
        </CardTitle>
        <CardDescription>Review your data before importing</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-center space-x-4">
              <Badge variant="outline">{csvFile.file.name}</Badge>
              <Badge variant="secondary">{csvFile.data.length} rows</Badge>
              <Badge variant="secondary">{csvFile.headers.length} columns</Badge>
            </div>
          </div>
          <div className="w-48">
            <Label htmlFor="import-type-preview">Import Type</Label>
            <Select value={importType} onValueChange={onImportTypeChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="contacts">Contacts</SelectItem>
                <SelectItem value="users">Users</SelectItem>
                <SelectItem value="call-logs">Call Logs</SelectItem>
                <SelectItem value="messages">Messages</SelectItem>
                <SelectItem value="invoices">Invoices</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                {csvFile.headers.map((header, index) => (
                  <TableHead key={index} className="font-medium">
                    {header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {previewRows.map((row, rowIndex) => (
                <TableRow key={rowIndex}>
                  {row.map((cell, cellIndex) => (
                    <TableCell key={cellIndex} className="max-w-xs truncate">
                      {cell}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {csvFile.data.length > 5 && (
          <div className="text-center text-sm text-muted-foreground">
            Showing first 5 rows of {csvFile.data.length} total rows
          </div>
        )}

        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <Button onClick={onNext} disabled={!importType}>
            Next: Map Columns
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
