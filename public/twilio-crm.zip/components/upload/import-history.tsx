"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle, AlertCircle, Clock, Download, Eye } from "lucide-react"

const importHistory = [
  {
    id: "1",
    filename: "contacts_january.csv",
    type: "Contacts",
    status: "Completed",
    records: 245,
    errors: 0,
    timestamp: "2024-01-15 14:30:00",
  },
  {
    id: "2",
    filename: "call_logs_december.csv",
    type: "Call Logs",
    status: "Completed",
    records: 1234,
    errors: 3,
    timestamp: "2024-01-14 09:15:00",
  },
  {
    id: "3",
    filename: "users_update.csv",
    type: "Users",
    status: "Failed",
    records: 0,
    errors: 15,
    timestamp: "2024-01-13 16:45:00",
  },
  {
    id: "4",
    filename: "messages_backup.csv",
    type: "Messages",
    status: "Processing",
    records: 567,
    errors: 0,
    timestamp: "2024-01-15 15:00:00",
  },
  {
    id: "5",
    filename: "invoices_q4.csv",
    type: "Invoices",
    status: "Completed",
    records: 89,
    errors: 1,
    timestamp: "2024-01-12 11:20:00",
  },
]

export function ImportHistory() {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "Failed":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "Processing":
        return <Clock className="h-4 w-4 text-yellow-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Processing":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Import History</CardTitle>
        <CardDescription>Recent CSV import jobs</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px]">
          <div className="space-y-4">
            {importHistory.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(item.status)}
                    <span className="font-medium text-sm">{item.filename}</span>
                  </div>
                  <Badge variant="secondary" className={getStatusColor(item.status)}>
                    {item.status}
                  </Badge>
                </div>

                <div className="space-y-1 text-xs text-muted-foreground">
                  <div>Type: {item.type}</div>
                  <div>Records: {item.records}</div>
                  {item.errors > 0 && <div className="text-red-500">Errors: {item.errors}</div>}
                  <div>{new Date(item.timestamp).toLocaleString()}</div>
                </div>

                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm">
                    <Eye className="mr-1 h-3 w-3" />
                    View
                  </Button>
                  {item.status === "Completed" && (
                    <Button variant="ghost" size="sm">
                      <Download className="mr-1 h-3 w-3" />
                      Report
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
