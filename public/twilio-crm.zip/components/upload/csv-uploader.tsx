"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, CheckCircle, AlertCircle } from "lucide-react"
import { CsvPreview } from "./csv-preview"
import { ColumnMapping } from "./column-mapping"

interface CsvFile {
  file: File
  data: string[][]
  headers: string[]
}

export function CsvUploader() {
  const [dragActive, setDragActive] = useState(false)
  const [csvFile, setCsvFile] = useState<CsvFile | null>(null)
  const [importType, setImportType] = useState("")
  const [step, setStep] = useState<"upload" | "preview" | "mapping" | "importing" | "complete">("upload")
  const [importProgress, setImportProgress] = useState(0)
  const [importResults, setImportResults] = useState<{
    success: number
    errors: number
    warnings: string[]
  } | null>(null)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }, [])

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleFile = (file: File) => {
    if (file.type !== "text/csv" && !file.name.endsWith(".csv")) {
      alert("Please upload a CSV file")
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      const lines = text.split("\n").filter((line) => line.trim())
      const data = lines.map((line) => line.split(",").map((cell) => cell.trim().replace(/^"|"$/g, "")))
      const headers = data[0] || []
      const rows = data.slice(1)

      setCsvFile({
        file,
        data: rows,
        headers,
      })
      setStep("preview")
    }
    reader.readAsText(file)
  }

  const handleImport = () => {
    setStep("importing")
    setImportProgress(0)

    // Simulate import progress
    const interval = setInterval(() => {
      setImportProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setStep("complete")
          setImportResults({
            success: csvFile?.data.length || 0,
            errors: 0,
            warnings: ["Some phone numbers were formatted automatically", "2 duplicate entries were skipped"],
          })
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  const resetUploader = () => {
    setCsvFile(null)
    setImportType("")
    setStep("upload")
    setImportProgress(0)
    setImportResults(null)
  }

  if (step === "complete" && importResults) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span>Import Complete</span>
          </CardTitle>
          <CardDescription>Your data has been successfully imported</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{importResults.success}</div>
              <div className="text-sm text-green-600">Records Imported</div>
            </div>
            <div className="text-center p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{importResults.errors}</div>
              <div className="text-sm text-red-600">Errors</div>
            </div>
          </div>

          {importResults.warnings.length > 0 && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-1">
                  <div className="font-medium">Warnings:</div>
                  {importResults.warnings.map((warning, index) => (
                    <div key={index} className="text-sm">
                      • {warning}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}

          <Button onClick={resetUploader} className="w-full">
            Import Another File
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (step === "importing") {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Importing Data</CardTitle>
          <CardDescription>Please wait while we import your data...</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Progress value={importProgress} className="w-full" />
          <div className="text-center text-sm text-muted-foreground">{importProgress}% complete</div>
        </CardContent>
      </Card>
    )
  }

  if (step === "mapping" && csvFile) {
    return (
      <ColumnMapping
        csvFile={csvFile}
        importType={importType}
        onBack={() => setStep("preview")}
        onImport={handleImport}
      />
    )
  }

  if (step === "preview" && csvFile) {
    return (
      <CsvPreview
        csvFile={csvFile}
        importType={importType}
        onImportTypeChange={setImportType}
        onBack={resetUploader}
        onNext={() => setStep("mapping")}
      />
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload CSV File</CardTitle>
        <CardDescription>Import contacts, call logs, or other data from CSV files</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-muted-foreground/50"
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Drop your CSV file here</h3>
            <p className="text-sm text-muted-foreground">or click to browse files</p>
          </div>
          <input
            type="file"
            accept=".csv"
            onChange={handleFileInput}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <Label htmlFor="import-type">Import Type</Label>
            <Select value={importType} onValueChange={setImportType}>
              <SelectTrigger>
                <SelectValue placeholder="Select what type of data you're importing" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="contacts">Contacts</SelectItem>
                <SelectItem value="users">Users</SelectItem>
                <SelectItem value="call-logs">Call Logs</SelectItem>
                <SelectItem value="messages">Messages</SelectItem>
                <SelectItem value="invoices">Invoices</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-1">
                <div className="font-medium">CSV Format Requirements:</div>
                <div className="text-sm">
                  • First row should contain column headers
                  <br />• Use comma (,) as delimiter
                  <br />• Enclose text with commas in quotes
                  <br />• Maximum file size: 10MB
                </div>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      </CardContent>
    </Card>
  )
}
